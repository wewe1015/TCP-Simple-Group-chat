var net = require('net');
net.createServer(processTCPconnection).listen(4040);
var clients = [];
function processTCPconnection(socket) {
    clients.push(socket);
    socket.on('data', function (data) {
        console.log(data.toString());
        broadcast("> " + data, socket);
    });
    socket.on('end', function () {
        clients.splice(clients.indexOf(socket), 1);
    });

}
function broadcast(message, sender) {
    clients.forEach(function (client) {
        if (client === sender) return;
        client.write(message);
    });
}

